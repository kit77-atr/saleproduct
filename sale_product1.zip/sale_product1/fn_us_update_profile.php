<?php
session_start();
include('config.php');

// ตรวจสอบว่ามีการส่งข้อมูลจากฟอร์มหรือไม่
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // รับค่าจากฟอร์ม
    $user_id = $_SESSION['user_id']; // ใช้ user_id จาก session
    $user_fname = $_POST['user_fname'];
    $user_sname = $_POST['user_sname'];
    $user_email = $_POST['user_email'];
    $user_address = $_POST['user_address'];
    $user_tel = $_POST['user_tel'];

    // เตรียมคำสั่งอัพเดท
    $stmt = $conn->prepare("UPDATE user_tb SET 
        user_fname = ?, 
        user_sname = ?, 
        user_email = ?, 
        user_address = ?, 
        user_tel = ? 
        WHERE user_id = ?");

    // ผูกค่าตัวแปรเข้ากับคำสั่ง
    $stmt->bind_param("sssssi", $user_fname, $user_sname, $user_email, $user_address, $user_tel, $user_id);

    // เรียกใช้งานคำสั่ง
    if ($stmt->execute()) {
        // อัพเดทตัวแปร session
        $_SESSION['user_fname'] = $user_fname;
        $_SESSION['user_sname'] = $user_sname;

        // เปลี่ยนเส้นทางไปยังหน้าโปรไฟล์
        header('Location: us_profile.php');
        exit; // หยุดการทำงานของสคริปต์หลังจากเปลี่ยนเส้นทาง
    } else {
        echo "เกิดข้อผิดพลาดในการอัพเดทข้อมูล: " . $stmt->error;
    }

    // ปิดคำสั่ง
    $stmt->close();
}

// ปิดการเชื่อมต่อฐานข้อมูล
$conn->close();
?>
