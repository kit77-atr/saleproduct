<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <title>Edit Profile</title>
    <style>
        body {
            background-color: #f9f9f9;
            color: #333;
        }
        .edit-profile-card {
            background-color: #fff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: auto;
        }
        .btn-custom {
            background-color: #007bff;
            color: #fff;
            border-radius: 20px;
        }
    </style>
</head>
<body>

<?php
    include('config.php');
    include('session.php');
    include('us_navbar.php');

    // Fetch user data
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT * FROM user_tb WHERE user_id = $user_id";
    $query = $conn->query($sql);
    $user = $query->fetch_assoc();

    // Process form submission for updating profile
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $fname = $_POST['user_fname'];
        $sname = $_POST['user_sname'];
        $email = $_POST['user_email'];
        $tel = $_POST['user_tel'];
        $address = $_POST['user_address'];
        
        $update_sql = "UPDATE user_tb SET user_fname='$fname', user_sname='$sname', user_email='$email', user_tel='$tel', user_address='$address' WHERE user_id=$user_id";
        
        if ($conn->query($update_sql) === TRUE) {
            echo "<div class='alert alert-success text-center'>Profile updated successfully!</div>";
        } else {
            echo "<div class='alert alert-danger text-center'>Error updating profile: " . $conn->error . "</div>";
        }
    }
?>

<div class="container my-5">
    <div class="edit-profile-card">
        <h3 class="text-center mb-4">Edit Profile</h3>
        
        <form action="fn_us_update_profile.php" method="POST">
            <div class="mb-3">
                <label for="user_fname" class="form-label">First Name</label>
                <input type="text" class="form-control" name="user_fname" id="user_fname" value="<?= $user['user_fname'] ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="user_sname" class="form-label">Last Name</label>
                <input type="text" class="form-control" name="user_sname" id="user_sname" value="<?= $user['user_sname'] ?>" required>
            </div>

            <div class="mb-3">
                <label for="user_email" class="form-label">Email</label>
                <input type="email" class="form-control" name="user_email" id="user_email" value="<?= $user['user_email'] ?>" required>
            </div>

            <div class="mb-3">
                <label for="user_tel" class="form-label">Phone</label>
                <input type="text" class="form-control" name="user_tel" id="user_tel" value="<?= $user['user_tel'] ?>" required>
            </div>

            <div class="mb-3">
                <label for="user_address" class="form-label">Address</label>
                <textarea class="form-control" name="user_address" id="user_address" rows="3" required><?= $user['user_address'] ?></textarea>
            </div>

            <div class="d-flex justify-content-between">
                <a href="us_proflie.php" class="btn btn-outline-secondary">Back</a>
                <button type="submit" class="btn btn-custom">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>
