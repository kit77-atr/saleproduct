<?php
session_start();
include('config.php'); // เชื่อมต่อฐานข้อมูล

// ตรวจสอบว่าผู้ใช้ล็อกอินอยู่หรือไม่
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // ถ้าไม่ล็อกอินให้ไปที่หน้าเข้าสู่ระบบ
    exit;
}

$user_id = $_SESSION['user_id'];

// ตรวจสอบว่ามีการส่งข้อมูลคำสั่งซื้อหรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_ids']) && is_array($_POST['product_ids'])) {
    $product_ids = $_POST['product_ids'];

    // เริ่มทำการยกเลิกคำสั่งซื้อ
    foreach ($product_ids as $product_id) {
        // ลบข้อมูลจาก order_detail_tb
        $sql_delete_detail = "DELETE FROM order_detail_tb WHERE product_id = ? AND order_id IN (SELECT order_id FROM order_tb WHERE user_id = ?)";
        $stmt_delete_detail = $conn->prepare($sql_delete_detail);
        $stmt_delete_detail->bind_param("ii", $product_id, $user_id);
        $stmt_delete_detail->execute();
        $stmt_delete_detail->close();

        // อัปเดตสถานะของคำสั่งซื้อใน order_tb
        $sql_update_order = "UPDATE order_tb SET order_status = 'ยกเลิก' WHERE order_id IN (SELECT order_id FROM order_detail_tb WHERE product_id = ? AND order_id IN (SELECT order_id FROM order_tb WHERE user_id = ?))";
        $stmt_update_order = $conn->prepare($sql_update_order);
        $stmt_update_order->bind_param("ii", $product_id, $user_id);
        $stmt_update_order->execute();
        $stmt_update_order->close();

        // อัปเดตสถานะใน trading_history_tb
        $sql_update_history = "UPDATE trading_history_tb SET order_status = 'ยกเลิก' WHERE user_id = ? AND product_id = ? AND order_status != 'ยกเลิก'";
        $stmt_update_history = $conn->prepare($sql_update_history);
        $stmt_update_history->bind_param("ii", $user_id, $product_id);
        $stmt_update_history->execute();
        $stmt_update_history->close();
    }

    // เปลี่ยนเส้นทางกลับไปที่หน้าประวัติการสั่งซื้อพร้อมข้อความยืนยัน
    echo "<script>alert('ยกเลิกคำสั่งซื้อเรียบร้อยแล้ว'); window.location.href='us_trading_history.php';</script>";
} else {
    echo "<script>alert('ไม่มีการเลือกสินค้าเพื่อลบ'); window.location.href='us_trading_history.php';</script>";
}

$conn->close();
?>
