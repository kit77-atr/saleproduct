<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>ตะกร้า สินค้า</title>
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2), url('https://images.unsplash.com/photo-1495546640888-499bcb01609f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&h=1000&q=80') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('1.png');
        }

        .container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
            position: relative;
            z-index: 1;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            overflow: hidden;
        }

        .btn-success {
            background-color: #28a745;
            border: none;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn-success:hover {
            background-color: #218838;
            transform: scale(1.1);
        }

        .btn-outline-danger {
            border-color: #dc3545;
            color: #dc3545;
        }

        .btn-outline-danger:hover {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <?php
        include('config.php');
        include('session.php');
        include('us_navbar.php');

        $user_id = $_SESSION['user_id'];
        $sql = "SELECT * FROM order_detail_tb INNER JOIN product_tb
                ON order_detail_tb.product_id = product_tb.product_id
                WHERE order_detail_tb.user_id = '$user_id'
                AND order_detail_tb.order_detail_status = 'wait'";
        $query = $conn->query($sql);
    ?>

    <div class="container mt-5">
        <form action="fn_accept_basket.php" method="post">
            <?php
            $all_price = 0;
            $items = [];
            while ($row = mysqli_fetch_array($query)) {
                $items[] = [
                    'id' => $row['order_detail_id'],
                    'total' => $row['order_detail_total'],
                    'name' => $row['product_name'],
                    'detail' => $row['product_detail'],
                    'img' => $row['product_img'],
                    'amount' => $row['order_detail_amount']
                ];
                $all_price += $row['order_detail_total'];
            }
            ?>
            <div id="product-list">
                <?php foreach ($items as $item) { ?>
                    <div class="card mb-3">
                        <div class="row g-0">
                            <div class="col-md-4 mt-auto mb-auto">
                                <center><img src="product_img/<?=$item['img']?>" class="img-fluid rounded-start" style="height: 100%"></center>
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title"><?=$item['name'];?></h5>
                                    <p class="card-text"><?=$item['detail'];?></p>
                                    <p class="card-text">จำนวนสั่งซื้อ: <?=$item['amount'];?></p>
                                    <p class="card-text"><small class="text-muted">ราคารวม: <span class="total-price"><?=$item['total'];?></span> บาท</small></p>
                                    <input type="checkbox" name="order_detail_ids[]" value="<?=$item['id'];?>" checked onchange="updateTotalPrice()"> เลือก
                                </div>
                                <div class="d-flex justify-content-end">
                                    <a href="fn_us_del_basket.php?order_detail_id=<?=$item['id'];?>" class="btn btn-outline-danger"  onclick="return confirm('คุณต้องการเอาสินค้านี้ออกจากตะกร้าใช่หรือไม่?');"><i class="bi bi-trash3"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <div class="d-flex">
                <button id="total-price" class="btn btn-outline-dark w-75 me-2" disabled>รวมราคาทั้งหมด: <span id="total-price-value"><?=$all_price;?></span> บาท</button>
                <input type="hidden" name="all_price" id="hidden-all-price" value="<?=$all_price;?>"> <!-- Hidden input for total price -->
                <button type="submit" class="btn btn-outline-success w-25">ยืนยันการซื้อ</button>
            </div>
        </form>
    </div>
    <br>

    <script>
        function updateTotalPrice() {
            const checkboxes = document.querySelectorAll('input[type="checkbox"]');
            const totalPriceElement = document.getElementById('total-price-value');
            const hiddenTotalPriceElement = document.getElementById('hidden-all-price');
            let total = 0;

            checkboxes.forEach(checkbox => {
                if (checkbox.checked) {
                    const priceElement = checkbox.closest('.card').querySelector('.total-price');
                    total += parseFloat(priceElement.textContent);
                }
            });

            totalPriceElement.textContent = total.toFixed(2);
            hiddenTotalPriceElement.value = total.toFixed(2);
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>
