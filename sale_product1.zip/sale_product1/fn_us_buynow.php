<?php
include('config.php');
include('session.php');

// ตรวจสอบว่ามีการส่ง product_id และ amount หรือไม่
if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];
    $amount = 1; // คุณสามารถปรับให้รับจำนวนที่ต้องการซื้อจากผู้ใช้

    // สร้างคำสั่ง SQL เพื่อบันทึกข้อมูลการสั่งซื้อ
    $user_id = $_SESSION['user_id']; // ตรวจสอบว่า user_id มีอยู่ใน session

    // บันทึกข้อมูลการสั่งซื้อใน order_tb
    $insert_order_sql = "INSERT INTO order_tb (user_id, order_date, order_status) VALUES ('$user_id', NOW(), 'รอดำเนินการ')";
    
    if ($conn->query($insert_order_sql) === TRUE) {
        $order_id = $conn->insert_id; // ดึง order_id ล่าสุด

        // บันทึกใน order_detail_tb
        $insert_detail_sql = "INSERT INTO order_detail_tb (order_id, product_id, order_detail_amount, order_detail_total) 
                              VALUES ('$order_id', '$product_id', '$amount', 
                              (SELECT product_price FROM product_tb WHERE product_id = '$product_id') * '$amount')";
        
        if ($conn->query($insert_detail_sql) === TRUE) {
            // เปลี่ยนเส้นทางไปที่หน้าประวัติการสั่งซื้อ
            header("Location: us_trading_history.php");
            exit();
        } else {
            echo "Error: " . $insert_detail_sql . "<br>" . $conn->error; // แสดงข้อความผิดพลาด
        }
    } else {
        echo "Error: " . $insert_order_sql . "<br>" . $conn->error; // แสดงข้อความผิดพลาด
    }
} else {
    // ถ้ามีปัญหากับพารามิเตอร์ ให้เปลี่ยนเส้นทางกลับไปยังหน้าหลักหรือแสดงข้อความแสดงข้อผิดพลาด
    header("Location: user_index.php");
    exit();
}
?>
