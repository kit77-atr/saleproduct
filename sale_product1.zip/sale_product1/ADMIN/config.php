<?php
    $host ="localhost";
    $config_user="root";
    $config_password="";
    $config_db="sale_product";

    //config
    $conn=mysqli_connect($host, $config_user, $config_password, $config_db);
    mysqli_set_charset($conn, "utf8");
    

    //set time
    date_default_timezone_set("asia/bangkok");
    $date=date("y-m-d");
    $time=date("h:i:s");

    //no db
    if(!$conn){
        echo "no connect db";
    }


?>