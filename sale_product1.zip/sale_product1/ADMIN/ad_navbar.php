<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
  <div class="container-fluid">
    <a class="navbar-brand" href="ad_home.php">
      <img src="img/logo.png" alt="Avatar Logo" style="width:50px;" class="rounded-pill"> 
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar" aria-controls="collapsibleNavbar" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="ad_home.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ad_user_regis.php">User Register</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ad_user_manage.php">User Manage</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Products</a>
          <ul class="dropdown-menu bg-dark">
            <li><a class="dropdown-item text-light" href="ad_product.php">All Products</a></li>
            <li><a class="dropdown-item text-light" href="ad_addproduct.php">Add Product</a></li>
            <li><a class="dropdown-item text-light" href="ad_product_type.php">Product Types</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <div class="d-flex">
      <a href="logout.php" class="btn btn-outline-danger">Logout</a>
    </div>
  </div>
</nav>
