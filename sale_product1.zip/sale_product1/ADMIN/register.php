<!doctype html>
<html lang="en">
<head>
     
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
      
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
        <link rel="stylesheet" href="css/style.css">
        <title>สมัครสมาชิก</title>
        <style>
                body {
                background-image: url("3.jpg");
                background-color:white;
                }
             h2{
                background-color:white;
                color:#000000;
                width:200px;
                height: 50px;
                box-shadow: 0 2px 5px rgba(0, 0, 2, 2.8); /* เงาที่เข้มขึ้น */
             }
             img {
                 border-radius: 50%;
                }
                form{
                        background-color: white;
                        padding: 20px;
                        border-radius: 5px;
                        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                        box-shadow: 0 2px 5px rgba(0, 0, 2, 2.8); /* เงาที่เข้มขึ้น */
                        
                }



        </style>
</head>
<body>
        <center></center>
    <div class="container w-50">
         <center>

                <img src="1.png" wight="200px" height="200px">
                <h2 class="mt-5">สมัครสมาชิก</h2>
         </center>
        <form action="fn_register.php" method="post" enctype="multipart/form-data">
            
                <div class="form-floating mt-3">
                        <input type="text" class="form-control" name="user_fname" id="user_fname" placeholder="user_fname" required>
                        <label for="user_fname">Firstname</label>
                        
                </div>
     
                <div class="form-floating mt-3">
                        <input type="text" class="form-control" name="user_sname" id="user_sname" placeholder="user_sname"required>
                        <label for="user_sname">surname</label>
                        
                </div>

        
                <div class="form-floating mt-3">
                        <input type="text" class="form-control" name="user_email" id="user_email" placeholder="user_email"required>
                        <label for="user_email">Email</label>
                        
                </div>

                <div class="form-floating mt-3">
                        <input type="text" class="form-control" name="user_address" id="user_address" placeholder="user_address"required>
                        <label for="user_address">Address</label>
                        
                </div>
                
                <div class="form-floating mt-3">
                        <input type="text" class="form-control" name="user_Tel" id="user_Tel" placeholder="user_Tel"required>
                        <label for="user_Tel">Tel</label>
                        
                </div>

                <div class="form-floating mt-3">
                        <input type="text" class="form-control" name="user_username" id="user_username" placeholder="user_username"required>
                        <label for="user_username">Username</label>
                        
                </div>

                
                <div class="form-floating mt-3">
                        <input type="password" class="form-control" name="user_Password" id="user_Password" placeholder="user_Password"required>
                        <label for="user_Password">Password</label>
                        
                </div>

                <div class="form-floating mt-3">
                        <input type="password" class="form-control" name="user_Password2" id="user_Password2" placeholder="user_Password2"required>
                        <label for="user_Password2">Password2</label>
                        
                </div>

                <div class="form-floating mt-3">
                </div>

                <input type="file" class="form-control" name="img" id="img" placeholder="img">
                       
                
                <div class="d-flex justify-content-end mt-3">
                        <a href="login.php" class="btn btn-primary me-2 w-25">Cancal</a>
                        <input type="submit" class="btn-success w-25"  value="Login">
                </div>
        </div>
</center>
             
              



<center>
        <marquee behavior="" direction="" > <img src="1.jpg" class="mt-5"></img></marquee>
</center>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</body>
</html>



