<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('1.png'); /* เปลี่ยนเป็น URL ของรูปพื้นหลัง */
            background-repeat: no-repeat;
            background-size: cover; /* ทำให้รูปพื้นหลังครอบคลุมทั้งหน้า */
            background-attachment: fixed; /* ทำให้รูปพื้นหลังไม่เลื่อนเมื่อเลื่อนหน้า */
            height: 100vh; /* ความสูงของ body จะครอบคลุม 100% ของ viewport */
        }
        
        .adbg {
            background-image: url('img/bg.png');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: top center;
            background-size: cover;
            height: 100vh;
            opacity: 0.7;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .adtext {
            text-align: center;
            color: #fff;
            padding: 20px;
            background: rgba(0, 0, 0, 0.5);
            border-radius: 15px;
        }
        h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            margin-bottom: 30px;
        }
        .action-buttons {
            margin-top: 20px;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
    </style>
    <title>Admin Page</title>
</head>
<body>
    <?php
        include('config.php');
        include('session.php');
        include('ad_navbar.php');
    ?>
    
    <div class="adbg">
        <div class="adtext">
            <h1>Welcome to the Admin Panel</h1>
            <p>Please select an option from the menu to manage the system.</p>
            <div class="action-buttons">
                <a href="user_management.php" class="btn btn-custom">Manage Users</a>
                <a href="product_management.php" class="btn btn-custom">Manage Products</a>
                <a href="order_management.php" class="btn btn-custom">Manage Orders</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>
