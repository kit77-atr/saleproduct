<?php
    include('config.php');

    $product_type_id = $_POST['product_type_id'];
    $product_type_name = $_POST['product_type_name'];

    $sql = "UPDATE product_type_tb SET product_type_name = '$product_type_name' WHERE product_type_id = '$product_type_id'";
    mysqli_query($conn, $sql);

    echo "
        <script>
            alert('แก้ไขประเภทสินค้าเรียบร้อยแล้ว...');
            window.location = 'ad_product_type.php';
        </script>
    ";
    
?>