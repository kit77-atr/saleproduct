<?php
    include('config.php');
    include('session.php');

    $product_name = $_POST['product_name'];
    $product_detail = $_POST['product_detail'];
    $product_price = $_POST['product_price'];
    $product_type_id = $_POST['product_type_id'];

    $user_id = $_SESSION['user_id'];

    if($product_type_id == 0) {
            echo "
             <script>
                alert('เลือกประเภทของสินค้าก่อน')
                history.back();

             </script>
            ";

        } else {
            if(isset($_FILES['img']['name'])){
                $img = uniqid().".".pathinfo($_FILES['img']['name'],PATHINFO_EXTENSION);
                $path = "product_img/";
                move_uploaded_file($_FILES['img']['tmp_name'],$path.$img);
            }
    
            $sql = "INSERT INTO product_tb VALUES(NULL, '$product_name', '$product_detail', '$product_price',  '$img', '$product_type_id',  '$user_id')";
            $conn->query($sql);

          
                echo "
                 <script>
                    alert('เพิ่มสินค้าเรียบร้อย');
                   window.location = 'ad_product.php';
    
                 </script>
                ";
        }
?>