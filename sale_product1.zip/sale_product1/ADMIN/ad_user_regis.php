<!doctype html>
<html lang="en">
<head>
     
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        body {
            background-color: #333;
            color: white;
            font-family: Arial, sans-serif;
        }
        h2, p {
            text-align: center;
            margin-top: 20px;
        }
        .container {
            background-color: #1c1c1c;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
            margin-top: 40px;
        }
        .table {
            margin-top: 20px;
            border-radius: 5px;
            overflow: hidden;
        }
        .btn-success, .btn-danger {
            width: 100%;
        }
        .btn-success {
            background-color: #28a745;
        }
        .btn-danger {
            background-color: #dc3545;
        }
        .table-dark {
            background-color: #343a40;
        }
        img.user-img {
            width: 80px;
            height: auto;
            border-radius: 10%;
        }
        .footer-marquee {
            margin-top: 30px;
            background-color: #222;
            padding: 10px 0;
            border-radius: 5px;
            overflow: hidden;
        }
        .footer-marquee img {
            width: 100px;
            margin: 0 15px;
        }
    </style>
    
    <title>Admin User Registration</title>
   
</head>
<body>
   <?php
        include('config.php');
        include('session.php');
        include('ad_navbar.php');

        $user_fname = $_SESSION['user_fname'];
        $user_sname = $_SESSION['user_sname'];
   ?>
   
   <div class="container">
        <h2>Approve User Registration</h2>
        <p>Manage pending user registrations</p>
        <table class="table table-dark table-striped text-center">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Profile Picture</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM user_tb WHERE user_status = 'wait'";
                $query = $conn->query($sql);

                while($row = mysqli_fetch_array($query)) {
                ?>
                <tr>
                    <td><?=$row['user_id']?></td>
                    <td><?=$row['user_fname']?></td>
                    <td><?=$row['user_sname']?></td>
                    <td><?=$row['user_address']?></td>
                    <td><?=$row['user_tel']?></td>
                    <td><?=$row['user_email']?></td>
                    <td><?=$row['user_username']?></td>
                    <td><img src="user_img/<?=$row['user_img']?>" class="user-img"></td>
                    <td>
                        <a href="fn_accept.php?user_id=<?=$row['user_id'];?>" class="btn btn-success mb-2">อนุมัติ</a>
                        <a href="fn_cancel.php?user_id=<?=$row['user_id'];?>" class="btn btn-danger" onclick="return confirm('Are you sure?');">ยกเลิก</a>
                    </td>
                </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
   </div>
   
   <center>
       <div class="footer-marquee">
           <marquee behavior="scroll" direction="left">
               <img src="10.jpg" alt="Image 1">
               <img src="1.jpg" alt="Image 2">
           </marquee>
       </div>
   </center>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
