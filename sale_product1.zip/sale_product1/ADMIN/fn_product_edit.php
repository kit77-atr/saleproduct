<?php
    include('config.php');

    $product_id =  $_POST['product_id'];
    $product_name =  $_POST['product_name'];
    $product_detail =  $_POST['product_detail'];
    $product_price =  $_POST['product_price'];
    $product_type_id = $_POST['product_type_id'];

    if($product_type_id == 0) {
        echo "
            <script>
                alert('กรุณาเลือกประเภทของสินค้าก่อน...');
                history.back();
            </script>
        ";
    } else {
        $sql = "UPDATE product_tb SET 
            product_name = '$product_name',
            product_detail = '$product_detail', 
            product_price = '$product_price',
            product_type_id = '$product_type_id' 
            WHERE product_id = '$product_id'";
        $conn->query($sql);

        echo "
            <script>
                alert('แก้ไขรายละเอียดสินค้าเรียบร้อยแล้ว');
                window.location = 'ad_product.php';
            </script>
        ";
    }
?>