<?php
    include("config.php");
    
    $user_fname = $_POST['user_fname'];
    $user_sname = $_POST['user_sname'];
    $user_email = $_POST['user_email'];
    $user_address = $_POST['user_address'];
    $user_Tel = $_POST['user_Tel'];
    $user_username = $_POST['user_username'];
    $user_Password = $_POST['user_Password'];
    $user_Password2 = $_POST['user_Password2'];
    

    if($user_Password  ==  $user_Password2){
        if(isset($_FILES['img']['name'])){
            $img = uniqid().".".pathinfo($_FILES['img']['name'],PATHINFO_EXTENSION);
            $path = "user_img/";
            move_uploaded_file($_FILES['img']['tmp_name'],$path.$img);
             }

             $sql = "INSERT INTO user_tb VALUES(NULL, '$user_fname','$user_sname','$user_email', '$user_address','$user_Tel',  '$user_username', '$user_Password','$img', 'wait')";
             mysqli_query($conn, $sql);


             echo "
               <script>
                     alert('สมัครเสร็จเเล้วรอเข้าได้เลยไอ่สัส');
                    window.location = 'login.php';
            </script>
             ";
       } else{ 
        echo "
        <script>
              alert('ใส่รหัสผ่านให้ตรงกันดิไอ่สัส');
             history.back();
     </script>
      ";

    }
























?>