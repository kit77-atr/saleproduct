<?php
    include('config.php');

    $product_id = $_REQUEST['product_id'];

    $sql = "DELETE FROM product_tb WHERE product_id = '$product_id'";
    $conn->query($sql);

    echo "
        <script>
            alert('ลบเรียบร้อยแล้ว...');
            window.location = 'ad_product.php';
        </script>
    ";
?>