<!doctype html>
<html lang="en">
<head>
     
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
      
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
        <link rel="stylesheet" href="css/style.css">
        <title>เข้าสู่ระบบ</title>
        <style>
                body {
                background-image: url("3.jpg");
                font-family: arial, sans-serif;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                }
             h2{
              
                color:#000000;
                width:200px;
                height: 50px;
             }
             img {
                 border-radius: 50%;
                }
               
                form{
                        background-color: white;
                        padding: 20px;
                        border-radius: 5px;
                        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                        width: 500px;
                }
                form {
            background-color: #ffffff; /* สีพื้นหลังของกล่องล็อกอิน */
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 2, 2.8); /* เงาที่เข้มขึ้น */
            width: 500px;
        }

                /* สไตล์ฟอร์ม */
        form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        </style>
</head>
<body>
       <center>
    <div class="container ">
        <img src="0.png" alt="">
        
        <form action="fn_Login.php" method="post">
        <center>
               <h2 class="mt-5"> <b>ล็อกอิน</b></h2>
         </center>
                <div class="form-floating mt-3">
                        <input type="text" class="form-control" name="user_username" id="user_username" placeholder="user_username"required>
                        <label for="user_username">Username</label>
                        
                </div>
     
                <div class="form-floating mt-3">
                        <input type="password" class="form-control" name="user_password" id="user_password" placeholder="user_password"required>
                        <label for="user_password">password</label>
                        
                </div>
            
              
                <div class="d-flex justify-content-end mt-3">
                        <a href="register.php" class="btn btn-primary me-2 w-25">สมัครสมาชิก</a>
                        <input type="submit" class="btn-success w-25" value="Login">
                </div>
                
                </form>
                <center>
                <div class="d-flex justify-content-end mt-3">
                        <marquee behavior="" direction=""><img src=".jpg" alt=""></marquee>
                        </div>
                </center>

                </div>
                
 </center>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</body>
</html>