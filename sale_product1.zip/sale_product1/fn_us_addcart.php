<?php
    include('config.php');
    include('session.php');

    $product_id = $_REQUEST['product_id'];

    $user_id = $_SESSION['user_id'];

    $sql = "SELECT * FROM order_detail_tb WHERE user_id = '$user_id'
            AND product_id = '$product_id' AND order_detail_status = 'wait'";
    $query = $conn->query($sql);
    $row = mysqli_fetch_array($query);

    if(isset($row) == 1) {
        $sql = "SELECT * FROM order_detail_tb INNER JOIN product_tb
                ON order_detail_tb.product_id = product_tb.product_id
                WHERE order_detail_tb.user_id = '$user_id'
                AND order_detail_tb.product_id = '$product_id' AND order_detail_tb.order_detail_status = 'wait'";
        $query = $conn->query($sql);
        $row = mysqli_fetch_array($query);

        $product_price = $row['product_price'];
        $order_detail_amount = $row['order_detail_amount'];
        $order_detail_total = $row['order_detail_total'];

        $order_detail_amount = $order_detail_amount + 1;
        $order_detail_total = $order_detail_total + $product_price;

        $sql = "UPDATE order_detail_tb SET order_detail_amount = '$order_detail_amount',
                order_detail_total = '$order_detail_total' WHERE user_id = '$user_id'
                AND product_id = '$product_id' AND order_detail_status = 'wait'";
        $conn->query($sql);

        echo "
            <script>
                alert('เพิ่มจำนวนสินค้านี้เข้าในตะกร้าเรียบร้อยเเล้ว...');
                history.back();
            </script>
        ";


    } else {
        $sql = "SELECT * FROM product_tb WHERE product_id = '$product_id'";
        $query = $conn->query($sql);
        $row = mysqli_fetch_array($query);

        $product_price = $row['product_price'];

        $sql = "INSERT INTO order_detail_tb(user_id, product_id, order_detail_amount, order_detail_total, order_detail_status)
                VALUES('$user_id', '$product_id', '1', '$product_price', 'wait')";
        $conn->query($sql);

        echo "
            <script>
                alert('เพิ่มสินค้าเข้าในตะกร้าเรียบร้อยแล้ว...');
                history.back();
            </script>
        ";
    }
?>