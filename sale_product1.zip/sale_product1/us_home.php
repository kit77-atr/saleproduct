<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>User Index</title>
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2), url('https://images.unsplash.com/photo-1495546640888-499bcb01609f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&h=1000&q=80') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('1.png');
        }

        .container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
            position: relative;
            z-index: 1;
        }

        .search-form {
            margin-bottom: 30px;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            overflow: hidden;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .card-img-top {
            object-fit: cover;
            border-radius: 15px 15px 0 0;
            height: 200px;
        }

        .card-body {
            padding: 20px;
        }

        .card-title {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 15px;
        }

        .card-text {
            font-size: 1rem;
            color: #555;
        }

        .btn-success, .btn-primary {
            transition: background-color 0.3s, transform 0.3s;
            margin-right: 5px;
        }

        .btn-success:hover, .btn-primary:hover {
            transform: scale(1.1);
        }

        .navbar, .btn {
            background-color: rgba(0, 0, 0, 0.7);
            color: #fff;
        }
    </style>
</head>
<body>
    <?php
        include('config.php');
        include('session.php');
        include('us_navbar.php');
    ?>

    <div class="container mt-5">
        <form action="#" method="post" class="search-form d-flex">
            <input type="text" class="form-control me-2" name="search" id="search" placeholder="Search...">
            <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i></button>
        </form>

        <?php
        $search = $_POST['search'] ?? '';
        ?>
        
        <div class="row row-cols-1 row-cols-md-4 g-4">
            <?php
            if ($search == "") {
                $sql = "SELECT * FROM product_tb INNER JOIN product_type_tb
                        ON product_tb.product_type_id = product_type_tb.product_type_id";
            } else {
                $sql = "SELECT * FROM product_tb INNER JOIN product_type_tb
                        ON product_tb.product_type_id = product_type_tb.product_type_id
                        WHERE product_tb.product_name LIKE '%$search%'";
            }
            $query = $conn->query($sql);
            while ($row = mysqli_fetch_array($query)) {
            ?>
            <div class="col">
                <div class="card h-100">
                    <img src="product_img/<?=$row['product_img'];?>" class="card-img-top">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?=$row['product_name'];?><hr></h5>
                        <p class="card-text"><?=$row['product_detail'];?></p>
                        <div class="d-flex justify-content-between mt-auto">
                            <span class="card-text mt-2 font-weight-bold"><?=$row['product_price'];?> ฿</span>
                            <!-- ปุ่มเพิ่มสินค้าลงตะกร้า -->
                            <a href="fn_us_addcart.php?product_id=<?=$row['product_id'];?>" class="btn btn-success"><i class="bi bi-basket-fill"></i> เพิ่มลงตะกร้า</a>
                            <!-- ปุ่มซื้อสินค้า -->
                            <a href="fn_us_buynow.php?product_id=<?=$row['product_id'];?>" class="btn btn-primary"><i class="bi bi-cash"></i> ซื้อสินค้า</a>
                        </div>
                    </div>  
                </div>
            </div>
            <?php 
            }
            ?>
        </div>
    </div>
    <br>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>