<?php
    include('config.php');
    include('session.php');

    $all_price = $_REQUEST['all_price'];
    $user_id = $_SESSION['user_id'];


    $sql = "INSERT INTO order_tb VALUES('', '$date', '$time', 
                                        '$all_price', '$user_id', 'wait')";

    $conn->query($sql);
    $sql = "SELECT order_id FROM order_tb WHERE user_id ='$user_id'
         AND order_status = 'wait'
         ORDER BY order_id DESC";

    $query = $conn->query($sql);
    $row = mysqli_fetch_array($query);

    $order_id =  $row['order_id'];

    $sql = "UPDATE order_detail_tb SET 
            order_id = '$order_id', order_detail_status = 'success' 
            WHERE user_id = '$user_id' AND  order_detail_status = 'wait'";
    $conn->query($sql);

    echo "
    <script>
        alert('ยืนยันการสั่งซื้อเรียบร้อย....');
        window.location = 'us_trading_history.php';
    </script>
";










?>