-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2024 at 04:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sale_product`
--

-- --------------------------------------------------------

--
-- Table structure for table `order_detail_tb`
--

CREATE TABLE `order_detail_tb` (
  `order_detail_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `order_detail_amount` int(11) NOT NULL,
  `order_detail_total` int(11) NOT NULL,
  `order_detail_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_detail_tb`
--

INSERT INTO `order_detail_tb` (`order_detail_id`, `user_id`, `order_id`, `product_id`, `order_detail_amount`, `order_detail_total`, `order_detail_status`) VALUES
(15, 0, 49, 2, 3, 15000, 0),
(16, 0, 50, 2, 3, 15000, 0),
(17, 0, 51, 2, 3, 15000, 0),
(18, 0, 52, 2, 3, 15000, 0),
(19, 0, 53, 2, 3, 15000, 0),
(20, 0, 54, 2, 3, 15000, 0),
(21, 0, 55, 2, 3, 15000, 0),
(22, 0, 56, 2, 3, 15000, 0),
(157, 3, 212, 1, 3, 15000, 0),
(159, 3, 0, 4, 1, 100, 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_tb`
--

CREATE TABLE `order_tb` (
  `order_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `order_time` time NOT NULL,
  `order_sum_price` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_tb`
--

INSERT INTO `order_tb` (`order_id`, `order_date`, `order_time`, `order_sum_price`, `user_id`, `order_status`) VALUES
(165, '2024-11-04', '09:43:26', 5000, 3, 'wait'),
(166, '2024-11-04', '09:43:39', 5000, 3, 'wait'),
(167, '2024-11-04', '09:43:50', 10000, 3, 'wait'),
(168, '2024-11-04', '09:44:06', 15000, 3, 'wait'),
(169, '2024-11-04', '09:44:10', 15000, 3, 'wait'),
(170, '2024-11-04', '09:44:17', 15000, 3, 'wait'),
(171, '2024-11-04', '09:44:27', 20000, 3, 'wait'),
(172, '2024-11-04', '09:46:32', 5000, 3, 'wait'),
(173, '2024-11-04', '09:46:44', 10000, 3, 'wait'),
(174, '2024-11-04', '09:48:09', 10000, 3, 'wait'),
(175, '2024-11-04', '09:49:43', 5000, 3, 'wait'),
(176, '2024-11-04', '09:52:56', 5000, 3, 'wait'),
(177, '2024-11-04', '09:53:08', 5000, 3, 'wait'),
(178, '2024-11-04', '09:53:25', 5000, 3, 'wait'),
(179, '2024-11-04', '09:53:52', 5000, 3, 'wait'),
(180, '2024-11-04', '09:54:03', 5000, 3, 'wait'),
(181, '2024-11-04', '09:54:19', 5000, 3, 'wait'),
(182, '2024-11-04', '09:54:46', 5000, 3, 'wait'),
(183, '2024-11-04', '09:55:19', 5000, 3, 'wait'),
(184, '2024-11-04', '09:55:27', 10000, 3, 'wait'),
(185, '2024-11-04', '09:57:28', 20, 3, 'wait'),
(186, '2024-11-04', '09:57:38', 40, 3, 'wait'),
(187, '2024-11-04', '09:59:12', 5000, 3, 'wait'),
(188, '2024-11-04', '09:59:21', 10000, 3, 'wait'),
(189, '2024-11-04', '10:00:33', 5000, 3, 'wait'),
(190, '2024-11-04', '10:01:05', 5000, 3, 'wait'),
(191, '2024-11-04', '10:01:13', 10000, 3, 'wait'),
(192, '2024-11-04', '10:01:22', 15000, 3, 'wait'),
(193, '2024-11-04', '10:01:34', 5000, 3, 'wait'),
(194, '2024-11-04', '10:01:49', 15100, 3, 'wait'),
(195, '2024-11-04', '10:07:57', 5000, 3, 'wait'),
(196, '2024-11-04', '10:08:22', 5000, 3, 'wait'),
(197, '2024-11-04', '10:08:38', 5000, 3, 'wait'),
(198, '2024-11-04', '10:09:09', 5000, 3, 'wait'),
(199, '2024-11-04', '10:09:21', 5000, 3, 'wait'),
(200, '2024-11-04', '10:09:29', 10000, 3, 'wait'),
(201, '2024-11-04', '10:16:52', 5000, 3, 'wait'),
(202, '2024-11-04', '10:17:04', 5000, 3, 'wait'),
(203, '2024-11-04', '10:17:37', 5000, 3, 'wait'),
(204, '2024-11-04', '10:17:53', 5000, 3, 'wait'),
(205, '2024-11-04', '10:17:58', 10000, 3, 'wait'),
(206, '2024-11-04', '10:18:18', 15000, 3, 'wait'),
(207, '2024-11-04', '10:21:28', 5000, 3, 'wait'),
(208, '2024-11-04', '10:21:44', 20000, 3, 'wait'),
(209, '2024-11-04', '10:25:06', 5000, 3, 'wait'),
(210, '2024-11-04', '10:25:13', 10000, 3, 'wait'),
(211, '2024-11-04', '10:26:59', 5000, 3, 'wait'),
(212, '2024-11-04', '10:27:20', 10000, 3, 'wait'),
(213, '2024-11-04', '10:28:45', 5000, 6, 'wait'),
(214, '2024-11-04', '10:29:55', 5000, 6, 'wait'),
(215, '2024-11-04', '10:30:17', 5000, 6, 'wait'),
(216, '2024-11-04', '10:30:35', 100, 6, 'wait');

-- --------------------------------------------------------

--
-- Table structure for table `product_tb`
--

CREATE TABLE `product_tb` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_detail` text NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_img` text NOT NULL,
  `product_type_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_tb`
--

INSERT INTO `product_tb` (`product_id`, `product_name`, `product_detail`, `product_price`, `product_img`, `product_type_id`, `user_id`) VALUES
(1, 'เสื้อเเขนยาว', 'ใส่สบาย', 5000, '67273b63bfb79.png', 1, 2),
(2, 'เสื้อ', 'ฟหก', 5000, '67273a1e060c8.png', 1, 2),
(4, 'กางเกง', 'ขายาว', 100, '67276174963af.png', 1, 2),
(5, 'กางเกงนอก', 'ใส่สบาย', 20, '6728e0ca91358.png', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `product_type_tb`
--

CREATE TABLE `product_type_tb` (
  `product_type_id` int(50) NOT NULL,
  `product_type_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_type_tb`
--

INSERT INTO `product_type_tb` (`product_type_id`, `product_type_name`) VALUES
(1, 'เสื้อผ้า');

-- --------------------------------------------------------

--
-- Table structure for table `trading_history_tb`
--

CREATE TABLE `trading_history_tb` (
  `history_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `order_detail_amount` int(11) NOT NULL,
  `order_detail_total` decimal(10,2) NOT NULL,
  `order_date` date NOT NULL,
  `order_status` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trading_history_tb`
--

INSERT INTO `trading_history_tb` (`history_id`, `user_id`, `product_id`, `order_detail_amount`, `order_detail_total`, `order_date`, `order_status`, `created_at`, `updated_at`) VALUES
(163, 6, 1, 1, 5000.00, '2024-11-04', 'ยกเลิก', '2024-11-04 15:29:26', '0000-00-00'),
(164, 3, 1, 3, 15000.00, '2024-11-04', 'wait', '2024-11-04 15:29:13', '0000-00-00'),
(165, 6, 2, 1, 5000.00, '2024-11-04', 'ยกเลิก', '2024-11-04 15:30:26', '0000-00-00'),
(166, 6, 4, 1, 100.00, '2024-11-04', 'ยกเลิก', '2024-11-04 15:30:42', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `user_tb`
--

CREATE TABLE `user_tb` (
  `user_id` int(11) NOT NULL,
  `user_fname` varchar(100) NOT NULL,
  `user_sname` varchar(50) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_address` text NOT NULL,
  `user_tel` varchar(11) NOT NULL,
  `user_username` varchar(50) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_img` text NOT NULL,
  `user_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_tb`
--

INSERT INTO `user_tb` (`user_id`, `user_fname`, `user_sname`, `user_email`, `user_address`, `user_tel`, `user_username`, `user_password`, `user_img`, `user_status`) VALUES
(2, 'กิต', 'asd', 'sad@5698', '465/88', '0645', 'admin', '123', '6726562f2c079.png', 'admin'),
(3, 'bum4565', 'tee', 'sad@5698', '465/88', '0645456456', 'b', '123', '6727330f0e269.png', 'user'),
(4, 'กิต', 'asd', 'sad@5698', '465/88', '0645', 'kit', '123', '67273324b48e3.png', 'wait'),
(5, 'k', 'tee', 'sad@5698', '465/88', '0645', 'k', '123', '67273d00e3aa5.png', 'block'),
(6, 'lay', 'asd', 'sad@5698', '465/88', '0645', 'l', '123', '67276295e8206.png', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order_detail_tb`
--
ALTER TABLE `order_detail_tb`
  ADD PRIMARY KEY (`order_detail_id`);

--
-- Indexes for table `order_tb`
--
ALTER TABLE `order_tb`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product_tb`
--
ALTER TABLE `product_tb`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_type_tb`
--
ALTER TABLE `product_type_tb`
  ADD PRIMARY KEY (`product_type_id`);

--
-- Indexes for table `trading_history_tb`
--
ALTER TABLE `trading_history_tb`
  ADD PRIMARY KEY (`history_id`);

--
-- Indexes for table `user_tb`
--
ALTER TABLE `user_tb`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_detail_tb`
--
ALTER TABLE `order_detail_tb`
  MODIFY `order_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=163;

--
-- AUTO_INCREMENT for table `order_tb`
--
ALTER TABLE `order_tb`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `product_tb`
--
ALTER TABLE `product_tb`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product_type_tb`
--
ALTER TABLE `product_type_tb`
  MODIFY `product_type_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trading_history_tb`
--
ALTER TABLE `trading_history_tb`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;

--
-- AUTO_INCREMENT for table `user_tb`
--
ALTER TABLE `user_tb`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
