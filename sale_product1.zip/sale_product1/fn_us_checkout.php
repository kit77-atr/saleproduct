<?php
session_start();
include('config.php'); // ไฟล์เชื่อมต่อฐานข้อมูล

// ตรวจสอบว่ามีการส่ง product_id เข้ามาหรือไม่
if (!isset($_GET['product_id'])) {
    echo "ไม่มีสินค้าที่เลือก";
    exit();
}

$product_id = $_GET['product_id'];
$user_id = $_SESSION['user_id']; // สมมติว่าเก็บ user_id ไว้ใน session

// ดึงข้อมูลสินค้า
$sql = "SELECT * FROM product_tb WHERE product_id = '$product_id'";
$query = $conn->query($sql);
$product = mysqli_fetch_assoc($query);

if (!$product) {
    echo "ไม่พบสินค้าที่เลือก";
    exit();
}

// บันทึกการสั่งซื้อ
$order_sql = "INSERT INTO order_history_tb (user_id, product_id, product_price, order_date) 
              VALUES ('$user_id', '$product_id', '{$product['product_price']}', NOW())";
$conn->query($order_sql);

// หลังจากบันทึกสำเร็จให้เด้งไปยังหน้าประวัติการสั่งซื้อ
header("Location: us_order_history.php");
exit();
?>
