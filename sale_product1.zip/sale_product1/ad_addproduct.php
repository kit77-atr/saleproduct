<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <title>สมัครสมาชิก - Add Product</title>
    <style>
        body {
            background-image: url("background.jpg"); /* Replace with your background image */
            background-size: cover;
            background-repeat: no-repeat;
            background-color: #f7f9fc;
            font-family: Arial, sans-serif;
            background-image: url('1.png');
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            margin-top: 50px;
        }
        h2 {
            font-weight: bold;
            color: #333;
            text-align: center;
        }
        .form-control {
            background-color: #f1f3f6;
            border: none;
            padding: 15px;
            border-radius: 5px;
        }
        .form-control:focus {
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.8);
        }
        label {
            color: #555;
        }
        .btn-primary {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
        .btn {
            padding: 10px 20px;
            font-weight: bold;
        }
        .form-section {
            margin-top: 20px;
        }
        img.profile-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            margin-top: -75px;
        }
    </style>
</head>
<body>

<?php
    include('config.php');
    include('session.php');
    include('ad_navbar.php');
?>

<div class="container w-50">
    <center>
        <img src="logo.png" class="profile-img" alt="Profile Image">
        <h2 class="mt-4">Add New Product</h2>
    </center>

    <form action="fn_addproduct.php" method="post" enctype="multipart/form-data">
        <div class="form-section">
            <label for="product_name">ชื่อสินค้า</label>
            <input type="text" class="form-control" name="product_name" id="product_name" placeholder="Product Name" required>
        </div>
        
        <div class="form-section">
            <label for="product_detail">รายละเอียดสินค้า</label>
            <textarea class="form-control" name="product_detail" id="product_detail" placeholder="Product Detail" rows="4" required></textarea>
        </div>
        
        <div class="form-section">
            <label for="product_price">ราคา</label>
            <input type="text" class="form-control" name="product_price" id="product_price" placeholder="Product Price" required>
        </div>

        <div class="form-section">
            <label for="product_type_id">ประเภทสินค้า</label>
            <select class="form-control" name="product_type_id" id="product_type_id">
                <option value="0">กรุณาเลือกประเภทสินค้า</option>
                <?php
                $sql = "SELECT * FROM product_type_tb";
                $query = $conn->query($sql);
                while($row = mysqli_fetch_array($query)) {
                ?>
                <option value="<?=$row['product_type_id'];?>"><?=$row['product_type_name'];?></option>
                <?php
                }
                ?>
            </select>
        </div>

        <div class="form-section">
            <label for="product_img">อัปโหลดรูปภาพ</label>
            <input type="file" class="form-control" name="img" id="product_img" required>
        </div>

        <div class="d-flex justify-content-end mt-4">
            <a href="ad_product.php" class="btn btn-primary me-3">Cancel</a>
            <input type="submit" class="btn btn-success" value="Add Product">
        </div>
    </form>
</div>

<center>
    <marquee behavior="scroll" direction="left" class="mt-5">
        <img src="1.jpg" class="rounded" style="width:100px; margin-right:10px;">
        <img src="2.jpg" class="rounded" style="width:100px; margin-right:10px;">
        <img src="3.jpg" class="rounded" style="width:100px; margin-right:10px;">
    </marquee>
</center>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
