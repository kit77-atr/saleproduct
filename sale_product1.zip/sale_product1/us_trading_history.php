<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="css/style.css">
    <title>ประวัติการสั่งซื้อ</title>
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2), url('https://images.unsplash.com/photo-1495546640888-499bcb01609f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&h=1000&q=80') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            font-family: 'Roboto', sans-serif;
            background-image: url('1.png');
        }

        .container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
        }

        .card {
            border: none;
            border-radius: 15px;
            margin-bottom: 20px;
        }

        .btn-danger {
            background-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .qrcode-img {
            width: 200px; /* ขนาดของ QR Code */
            height: 200px;
        }
    </style>
</head>
<body>
    <?php
        include('config.php');
        include('session.php');
        include('us_navbar.php');

        $user_id = $_SESSION['user_id'];
        
        // ดึงข้อมูลการสั่งซื้อ โดยไม่ให้แสดงสินค้าซ้ำ
        $sql = "SELECT o.*, od.product_id, SUM(od.order_detail_amount) AS total_amount, SUM(od.order_detail_total) AS total_price, p.product_name 
                FROM order_tb o
                JOIN order_detail_tb od ON o.order_id = od.order_id
                JOIN product_tb p ON od.product_id = p.product_id
                WHERE o.user_id = '$user_id' 
                GROUP BY od.product_id
                ORDER BY o.order_date DESC";

        $query = $conn->query($sql);
    ?>

    <div class="container mt-5">
        <h2 class="text-center">ประวัติการสั่งซื้อของคุณ</h2>
        <?php
        if ($query->num_rows > 0) {
            echo '<form action="fn_cancel_order.php" method="POST">';
            while ($row = mysqli_fetch_array($query)) {
                // ตรวจสอบว่าประวัติคำสั่งซื้อนี้ถูกบันทึกใน trading_history_tb หรือยัง
                $check_sql = "SELECT * FROM trading_history_tb 
                              WHERE user_id = '$user_id' AND product_id = '{$row['product_id']}' 
                              AND order_date = '{$row['order_date']}' AND order_detail_amount = '{$row['total_amount']}'";
                $check_result = $conn->query($check_sql);

                if ($check_result->num_rows == 0) {
                    // บันทึกประวัติการสั่งซื้อไปยัง trading_history_tb ถ้าไม่มีอยู่แล้ว
                    $history_sql = "INSERT INTO trading_history_tb (user_id, product_id, order_detail_amount, order_detail_total, order_date, order_status) 
                                    VALUES ('$user_id', '{$row['product_id']}', '{$row['total_amount']}', '{$row['total_price']}', '{$row['order_date']}', '{$row['order_status']}')";
                    
                    if (!$conn->query($history_sql)) {
                        echo "Error: " . $history_sql . "<br>" . $conn->error; // แสดงข้อผิดพลาด
                    }
                }
        ?>
           <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($row['product_name']); ?></h5>
                    <p class="card-text">จำนวน: <?= htmlspecialchars($row['total_amount']); ?></p>
                    <p class="card-text">ราคารวม: <?= htmlspecialchars($row['total_price']); ?> บาท</p>
                    <p class="card-text">สถานะ: <?= htmlspecialchars($row['order_status']); ?></p>
                    <p class="card-text">วันที่สั่งซื้อ: <?= htmlspecialchars(date('d/m/Y', strtotime($row['order_date']))); ?></p>
                    <input type="checkbox" name="product_ids[]" value="<?= htmlspecialchars($row['product_id']); ?>" /> เลือกสำหรับยกเลิก
                </div>
            </div>
        <?php
            }
            
            echo '<button type="submit" class="btn btn-danger">ยกเลิกคำสั่งซื้อที่เลือก</button>';
            echo '</form>';
        } else {
            echo "<p class='text-center'>คุณยังไม่มีประวัติการสั่งซื้อ</p>";
        }
        ?>
        
        <div class="text-center mt-4">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#paymentModal">ชำระเงิน</button>
        </div>
    </div>

    <!-- Modal สำหรับรายละเอียดการชำระเงิน -->
    <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="paymentModalLabel">รายละเอียดการชำระเงิน</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php
                    // Reset pointer to the start of the result set
                    $query->data_seek(0); // Reset the result set pointer
                    
                    // คำนวณราคาสินค้าทั้งหมด
                    $total_price = 0;
                    while ($row = mysqli_fetch_array($query)) {
                        $total_price += $row['total_price'];
                    }
                    ?>
                    <p>ราคารวมทั้งหมด: <?= htmlspecialchars($total_price); ?> บาท</p>
                    <h4>QR Code สำหรับการชำระเงิน</h4>
                    <img src="Qrcode.jpg" class="qrcode-img" alt="QR Code" />
                    <p>Scan this QR code to make your payment.</p>
                </div>
                <div class="modal-footer">
                    <form action="fn_payment.php" method="POST">
                        <input type="hidden" name="total_price" value="<?= htmlspecialchars($total_price); ?>" />
                        <input type="hidden" name="user_id" value="<?= htmlspecialchars($user_id); ?>" />
                        <button type="submit" class="btn btn-primary">ยืนยันการชำระเงิน</button>
                    </form>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>
