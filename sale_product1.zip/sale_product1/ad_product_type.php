<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <title>Admin Page - Add Product Type</title>
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
            font-family: Arial, sans-serif;
            background-image: url('1.png');
        }
        h2, p {
            color: #ffffff;
        }
        .container {
            background-color: #1e1e1e;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            margin-top: 50px;
        }
        .form-floating input {
            background-color: #2e2e2e;
            border: none;
            color: #ffffff;
        }
        .form-floating input:focus {
            box-shadow: 0 0 5px rgba(100, 181, 246, 0.8);
        }
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
        .table {
            background-color: #2e2e2e;
            color: #ffffff;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-warning, .btn-danger {
            width: 45%;
        }
        .image-container {
            text-align: center;
            margin-top: 40px;
        }
        .image-container img {
            width: 100px;
            height: auto;
            margin: 0 10px;
            border-radius: 5px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }
        marquee img {
            margin: 10px;
        }
    </style>
</head>
<body>

<?php
    include('config.php');
    include('session.php');
    include('ad_navbar.php');

    $user_fname = $_SESSION['user_fname'];
    $user_sname = $_SESSION['user_sname'];
?>

<div class="container w-50">
    <h2>Add Product Type</h2>
    <p>เพิ่มประเภทของสินค้า</p>

    <form action="fn_product_type.php" method="post">
        <div class="form-floating mt-3">
            <input type="text" class="form-control" name="product_type_name" id="product_type_name" placeholder="Product Type Name" required>
            <label for="product_type_name">ชื่อประเภทสินค้า</label>
        </div>
        <button type="submit" class="btn btn-success w-100 mt-3">เพิ่มประเภทสินค้า</button>
    </form>

    <table class="table table-dark table-striped text-center mt-5">
        <thead>
            <tr>
                <th>รหัส</th>
                <th>ชื่อประเภทสินค้า</th>
                <th>จัดการ</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $sql = "SELECT * FROM product_type_tb";
                $query = $conn->query($sql);
                while($row = mysqli_fetch_array($query)) {
            ?>
            <tr>
                <td><?=$row['product_type_id'];?></td>
                <td><?=$row['product_type_name'];?></td>
                <td style="width:20%">
                    <a href="ad_product_type_Edit.php?product_type_id=<?=$row['product_type_id'];?>" class="btn btn-warning">Edit</a>
                    <a href="fn_product_type_Delete.php?product_type_id=<?=$row['product_type_id'];?>" class="btn btn-danger" onclick="return confirm('แน่ใจใช่ไหม?');">Delete</a>
                </td>
            </tr>
            <?php
                }
            ?>
        </tbody>
    </table>
</div>

<div class="image-container">
    <img src="10.jpg" alt="Product Image">
</div>

<center>
    <marquee behavior="scroll" direction="left" class="mt-4">
        <img src="1.jpg" alt="Additional Image">
        <img src="2.jpg" alt="Additional Image">
        <img src="3.jpg" alt="Additional Image">
    </marquee>
</center>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
