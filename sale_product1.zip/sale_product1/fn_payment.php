<?php
include('config.php');
include('session.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $total_price = $_POST['total_price'];

    // อัปเดตสถานะคำสั่งซื้อใน order_tb เป็น "ชำระเงินแล้ว"
    $update_sql = "UPDATE order_tb SET order_status = 'ชำระเงินแล้ว' WHERE user_id = '$user_id' AND order_status != 'ชำระเงินแล้ว'";

    if ($conn->query($update_sql) === TRUE) {
        // Redirect ไปที่หน้าประวัติการสั่งซื้อหลังจากอัปเดตสถานะ
        header("Location: us_trading_history.php?payment_success=1");
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
