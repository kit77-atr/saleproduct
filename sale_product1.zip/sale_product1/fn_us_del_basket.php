<?php
    include('config.php');
    include('session.php');

    $order_detail_id = $_REQUEST['order_detail_id'];
    $user_id = $_SESSION['user_id'];

    $sql = "DELETE FROM order_detail_tb 
            WHERE order_detail_id = '$order_detail_id' AND user_id = '$user_id'";
    $conn->query($sql);

    echo "
        <script>
            alert('ลบรายการสินค้านี้.....ออกจากตะกร้าเรียบร้อยแล้ว.');
            window.location = 'us_basket.php';
        </script>
    ";
?>