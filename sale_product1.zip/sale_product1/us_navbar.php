<?php
    

    $user_fname = $_SESSION['user_fname'];
    $user_sname = $_SESSION['user_sname'];


?>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="us_home.php">
        <img src="img/logo.png" alt="Logo" style="width:50px;" class="rounded-pill">   
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-between" id="collapsibleNavbar">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="us_home.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="us_profile.php">User Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="us_trading_history.php">Trading History</a>
            </li>  
        </ul>
         <ul class="navbar-nav">
            <li class="nav-item ">
                <a class="navbar-brand" href="us_basket.php">
                <img src="img/basket.png" alt="basket-icon" style="width: 40px">
                </a>
            </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"> <?=$user_fname?> <?=$user_sname?> </a>
                    <ul class="dropdown-menu bg-dark drodown-menu-lg-end">
                        <li><a class="dropdown-item text-light" href="us_change_pass.php">Change Password</a></li>
                        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </div>
        </ul>
    </div>
  </div>
</nav>