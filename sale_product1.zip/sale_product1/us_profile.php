<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <title>โปรไฟล์ผู้ใช้</title>
    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
            font-family: 'Roboto', sans-serif;
            background-image: url('1.png');
        }
        .profile-card {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.2s;
        }
        .profile-card:hover {
            transform: scale(1.02);
        }
        .profile-img {
            border-radius: 50%;
            width: 150px;
            height: 150px;
            margin-bottom: 15px;
            border: 4px solid #007bff;
            box-shadow: 0px 0px 10px rgba(0, 123, 255, 0.5);
        }
        .btn-custom {
            background-color: #007bff;
            color: #fff;
            border-radius: 20px;
            padding: 10px 20px;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        .btn-custom:hover {
            background-color: #0056b3;
            color: #fff;
        }
        .user-info {
            margin-top: 20px;
            padding: 15px;
            background: #e9ecef;
            border-radius: 10px;
        }
        .user-info p {
            margin: 10px 0;
        }
    </style>
</head>
<body>

<?php
    include('config.php');
    include('session.php');
    include('us_navbar.php');

    // Fetch user data
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT * FROM user_tb WHERE user_id = $user_id";
    $query = $conn->query($sql);
    $user = $query->fetch_assoc();
?>

<div class="container my-5">
    <div class="profile-card mx-auto p-4" style="max-width: 600px;">
        <img src="user_img/<?= $user['user_img'] ?>" alt="Profile Image" class="profile-img">
        <h2 class="text-primary"><?= $user['user_fname'] ?> <?= $user['user_sname'] ?></h2>
        
        <div class="user-info">
            <p><i class="fas fa-envelope me-2"></i> <?= htmlspecialchars($user['user_email']) ?></p>
            <p><i class="fas fa-map-marker-alt me-2"></i> <?= htmlspecialchars($user['user_address']) ?></p>
            <p><i class="fas fa-phone me-2"></i> <?= htmlspecialchars($user['user_tel']) ?></p>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            <a href="us_edit_profile.php" class="btn btn-custom me-2">แก้ไขโปรไฟล์</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>
