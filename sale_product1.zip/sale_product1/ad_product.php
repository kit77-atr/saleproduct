<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="css/style.css">
    <title>Admin Page - All Products</title>
    <style>
        body {
            background-color: #f4f6f9;
            color: #333;
            font-family: Arial, sans-serif;
            background-image: url('1.png');
        }
        .container {
            margin-top: 50px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-weight: bold;
            color: #5a5a5a;
        }
        p {
            text-align: center;
            color: #7d7d7d;
        }
        .table {
            margin-top: 20px;
        }
        .table-dark {
            background-color: #343a40;
        }
        .btn {
            width: 100%;
            font-size: 14px;
            font-weight: bold;
            border-radius: 4px;
        }
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        img {
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <?php
        include('config.php');
        include('session.php');
        include('ad_navbar.php');
    ?>

    <div class="container">
        <h2>All Products</h2>
        <p>Manage all products in the system</p>
        <table class="table table-dark table-striped text-center">
            <thead>
                <tr>
                    <th>Product ID</th>
                    <th>Name</th>
                    <th>Detail</th>
                    <th>Price</th>
                    <th>Image</th>
                    <th>Type ID</th>
                    <th>User ID</th>
                    <th style="width: 15%;">Manage</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM product_tb";
                $query = $conn->query($sql);

                while($row = mysqli_fetch_array($query)) {
                ?>
                <tr>
                    <td><?=$row['product_id'];?></td>
                    <td><?=$row['product_name'];?></td>
                    <td><?=$row['product_detail'];?></td>
                    <td><?=$row['product_price'];?></td>
                    <td><img src="product_img/<?=$row['product_img'];?>" style="width: 80px;"></td>
                    <td><?=$row['product_type_id'];?></td>
                    <td><?=$row['user_id'];?></td>
                    <td>
                        <a href="ad_product_edit.php?product_id=<?=$row['product_id'];?>" class="btn btn-success mb-2">Edit</a>
                        <a href="ad_product_editpic.php?product_id=<?=$row['product_id'];?>" class="btn btn-primary mb-2" onclick="return confirm('Confirm editing image?');">Edit Pic</a>
                        <a href="fn_product_delete.php?product_id=<?=$row['product_id'];?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                    </td>
                </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
