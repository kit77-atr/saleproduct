<?php
    include('config.php');

    $user_username = $_POST['user_username'];
    $user_password = $_POST['user_password'];

    $sql = "SELECT * FROM user_tb WHERE user_username = '$user_username' AND user_password = '$user_password'";
    $query = mysqli_query($conn, $sql);

     if(mysqli_num_rows($query) == 1){
         $row = mysqli_fetch_array($query);

         //การจดจำ//
         session_start();

         $_SESSION['user_id'] = $row['user_id'];
         $_SESSION['user_fname'] = $row['user_fname'];
         $_SESSION['user_sname'] = $row['user_sname'];
         $_SESSION['user_email'] = $row['user_email'];
         $_SESSION['user_address'] = $row['user_address'];
         $_SESSION['user_tel'] = $row['user_tel'];
         $_SESSION['user_username'] = $row['user_username'];
         $_SESSION['user_password'] = $row['user_password'];
         $_SESSION['use_img'] = $row['user_img'];
         $_SESSION['user_status'] = $row['user_status'];

         //แยกบทบาท//
         if($_SESSION['user_status'] == "admin"){
            echo "
            <script>
                 window.location = 'ad_home.php';
         </script>
          ";
         } else if($_SESSION['user_status'] == "user"){
            echo "
            <script>
                 window.location = 'us_home.php';
         </script>
          ";
         } else if($_SESSION['user_status'] == "wait"){
            echo "
            <script>
                alert('...ยังไม่ได้อนุมัติ...');
                 window.location = 'index.php';
         </script>
          ";
     } else if($_SESSION['user_status'] == "block"){
        echo "
        <script>
            alert('...บัญชีถูกระงับ...');
             window.location = 'login.php';
     </script>
      ";
     } 
     } else {
        echo "
        <script>
            alert('...ไม่มีบัญชีนี้ในระบบ...');
             window.location = 'index.php';
     </script>
      ";

    }

     
    
?>